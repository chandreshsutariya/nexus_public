import React from 'react';
import Upload from './components/Upload';

function App() {
  return (
    <div className="App">
      <h1>Face Recognition System</h1>
      <Upload />
    </div>
  );
}

export default App;
